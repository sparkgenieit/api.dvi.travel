// FILE: src/modules/itineraries/engines/helpers/distance.helper.ts

import { Prisma } from "@prisma/client";
import { minutesToDurationTime, minutesToTime } from "./time.helper";

type Tx = Prisma.TransactionClient;

export interface DistanceResult {
  distanceKm: number; // e.g. 8.42
  travelTime: string; // HH:MM:SS
  bufferTime: string; // HH:MM:SS
}

/**
 * Parse dvi_stored_locations.duration into TOTAL MINUTES.
 * Supports:
 * - "49 mins"
 * - "1 hour 56 mins"
 * - "3 hours 5 mins"
 * - "1 day 1 hour"
 * - "1 day 0 hours"
 * - "1 day 2 hours 15 mins"
 * Also supports numeric durations (treated as minutes).
 */
function parseDurationToMinutes(duration: any): number | null {
  if (duration == null) return null;

  if (typeof duration === "number" && Number.isFinite(duration)) {
    return Math.max(0, Math.floor(duration));
  }

  const s = String(duration).trim().toLowerCase();
  if (!s) return null;

  let days = 0;
  let hours = 0;
  let mins = 0;

  const dMatch = s.match(/(\d+)\s*day/);
  const hMatch = s.match(/(\d+)\s*hour/);
  const mMatch = s.match(/(\d+)\s*min/);

  if (dMatch) days = Number(dMatch[1] || 0);
  if (hMatch) hours = Number(hMatch[1] || 0);
  if (mMatch) mins = Number(mMatch[1] || 0);

  if (!dMatch && !hMatch && !mMatch) {
    const n = Number(s);
    if (Number.isFinite(n)) return Math.max(0, Math.floor(n));
    return null;
  }

  return days * 1440 + hours * 60 + mins;
}

export class DistanceHelper {
  async fromCoordinates(
    tx: Tx,
    startLat: number,
    startLon: number,
    endLat: number,
    endLon: number,
    travelLocationType: 1 | 2,
  ): Promise<DistanceResult> {
    const earthRadius = 6371;

    const startLatRad = (startLat * Math.PI) / 180;
    const startLonRad = (startLon * Math.PI) / 180;
    const endLatRad = (endLat * Math.PI) / 180;
    const endLonRad = (endLon * Math.PI) / 180;

    const latDiff = endLatRad - startLatRad;
    const lonDiff = endLonRad - startLonRad;

    const a =
      Math.pow(Math.sin(latDiff / 2), 2) +
      Math.cos(startLatRad) * Math.cos(endLatRad) * Math.pow(Math.sin(lonDiff / 2), 2);

    const distance = 2 * earthRadius * Math.asin(Math.sqrt(a));

    const correctionFactor = 1.5;
    const correctedDistance = distance * correctionFactor;

    const gs = await (tx as any).dvi_global_settings.findFirst({
      where: { deleted: 0, status: 1 },
    });

    const avgSpeedKmPerHr =
      travelLocationType === 1
        ? Number(gs?.itinerary_local_speed_limit ?? 40)
        : Number(gs?.itinerary_outstation_speed_limit ?? 60);

    const durationHours = correctedDistance / avgSpeedKmPerHr;
    const wholeHours = Math.floor(durationHours);
    const minutes = Math.round((durationHours - wholeHours) * 60);

    // This is a computed travel time (not from DB). It should never exceed 24h normally.
    const travelTime = `${String(wholeHours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:00`;

    const bufferTime = await this.getBufferTime(tx, travelLocationType);

    return { distanceKm: correctedDistance, travelTime, bufferTime };
  }

  async fromLocationId(tx: Tx, locationId: number, travelLocationType: 1 | 2): Promise<DistanceResult> {
    const loc = await (tx as any).dvi_stored_locations.findFirst({
      where: { location_ID: locationId },
    });

    if (!loc) {
      return { distanceKm: 0, travelTime: "00:00:00", bufferTime: "00:00:00" };
    }

    const distance = Number(loc.distance ?? 0);

    // ✅ duration in DB is string like "3 hours 5 mins" / "1 day 1 hour"
    const totalMinutes = parseDurationToMinutes(loc.duration);

    // ✅ IMPORTANT: use *duration* formatter (NO wrap)
    const travelTime = minutesToDurationTime(totalMinutes ?? 0);

    const bufferTime = await this.getBufferTime(tx, travelLocationType);

    return { distanceKm: distance, travelTime, bufferTime };
  }

  async fromSourceAndDestination(
    tx: Tx,
    sourceLocation: string,
    destinationLocation: string,
    travelLocationType: 1 | 2,
    sourceCoords?: { lat: number; lon: number },
    destCoords?: { lat: number; lon: number },
  ): Promise<DistanceResult> {
    const loc = await (tx as any).dvi_stored_locations.findFirst({
      where: {
        deleted: 0,
        status: 1,
        source_location: sourceLocation,
        destination_location: destinationLocation,
      },
      orderBy: { location_ID: "desc" },
    });

    if (loc) {
      const distance = Number(loc.distance ?? 0);

      const totalMinutes = parseDurationToMinutes(loc.duration);

      // ✅ IMPORTANT: use *duration* formatter (NO wrap)
      const travelTime = minutesToDurationTime(totalMinutes ?? 0);

      const bufferTime = await this.getBufferTime(tx, travelLocationType);
      return { distanceKm: distance, travelTime, bufferTime };
    }

    if (sourceCoords && destCoords) {
      return this.fromCoordinates(
        tx,
        sourceCoords.lat,
        sourceCoords.lon,
        destCoords.lat,
        destCoords.lon,
        travelLocationType,
      );
    }

    return { distanceKm: 0, travelTime: "00:00:00", bufferTime: "00:00:00" };
  }

  private async getBufferTime(tx: Tx, travelLocationType: 1 | 2): Promise<string> {
    const gs = await (tx as any).dvi_global_settings.findFirst({
      where: { deleted: 0, status: 1 },
    });

    if (!gs) return "00:00:00";

    const minutes =
      travelLocationType === 1
        ? Number(gs.itinerary_local_buffer_time ?? 0)
        : Number(gs.itinerary_outstation_buffer_time ?? 0);

    // Buffer is a TIME amount; wrapping is fine here.
    return minutesToTime(minutes);
  }
}
