import { Body, Controller, Param, Post, Query } from '@nestjs/common';
import {
  ApiBody,
  ApiExtraModels,
  ApiOperation,
  ApiQuery,
  ApiTags,
  ApiBearerAuth,
} from '@nestjs/swagger';
import {
  CreateItineraryDto,
  CreatePlanDto,
  CreateRouteDto,
  CreateTravellerDto,
  CreateVehicleDto,
} from './dto/create-itinerary.dto';
import { ItinerariesService } from './itineraries.service';

@ApiTags('Itineraries')
@ApiBearerAuth() // uses default bearer auth from main.ts
@ApiExtraModels(
  CreateItineraryDto,
  CreatePlanDto,
  CreateRouteDto,
  CreateVehicleDto,
  CreateTravellerDto,
)
@Controller('itineraries')
export class ItinerariesController {
  constructor(private readonly svc: ItinerariesService) {}

  @Post()
  @ApiOperation({
    summary:
      'Create OR Update plan + routes + vehicles + travellers (NO hotspots yet). Use plan.itinerary_plan_id for update.',
  })
  @ApiBody({
    type: CreateItineraryDto,
    examples: {
      create: {
        summary: 'Create (no ids)',
        value: {
          plan: {
            agent_id: 126,
            staff_id: 0,
            location_id: 0,
            arrival_point: 'Chennai International Airport',
            departure_point: 'Pondicherry',
            itinerary_preference: 3,
            itinerary_type: 2,
            preferred_hotel_category: [13],
            hotel_facilities: ['24hr-business-center', '24hr-checkin'],
            trip_start_date: '2025-11-29T12:00:00+05:30',
            trip_end_date: '2025-12-01T12:00:00+05:30',
            pick_up_date_and_time: '2025-11-29T12:00:00+05:30',
            arrival_type: 1,
            departure_type: 1,
            no_of_nights: 2,
            no_of_days: 3,
            budget: 15000,
            entry_ticket_required: 0,
            guide_for_itinerary: 0,
            nationality: 101,
            food_type: 1,
            adult_count: 2,
            child_count: 0,
            infant_count: 0,
            special_instructions: '',
          },
          routes: [
            {
              location_name: 'Chennai International Airport',
              next_visiting_location: 'Chennai',
              itinerary_route_date: '2025-11-29T00:00:00+05:30',
              no_of_days: 1,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
            {
              location_name: 'Chennai',
              next_visiting_location: 'Pondicherry',
              itinerary_route_date: '2025-11-30T00:00:00+05:30',
              no_of_days: 2,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
            {
              location_name: 'Pondicherry',
              next_visiting_location: 'Pondicherry',
              itinerary_route_date: '2025-12-01T00:00:00+05:30',
              no_of_days: 3,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
          ],
          vehicles: [{ vehicle_type_id: 20, vehicle_count: 1 }],
          travellers: [
            { room_id: 1, traveller_type: 1 },
            { room_id: 1, traveller_type: 1 },
          ],
        },
      },

      update: {
        summary:
          'Update (PHP-like hidden IDs): plan.itinerary_plan_id + routes[].itinerary_route_id + vehicles[].vehicle_details_id',
        value: {
          plan: {
            itinerary_plan_id: 28230, // <-- UPDATE EXISTING PLAN
            agent_id: 126,
            staff_id: 0,
            location_id: 0,
            arrival_point: 'Chennai International Airport',
            departure_point: 'Pondicherry',
            itinerary_preference: 3,
            itinerary_type: 2,
            preferred_hotel_category: [13],
            hotel_facilities: ['24hr-business-center', '24hr-checkin'],
            trip_start_date: '2025-11-29T12:00:00+05:30',
            trip_end_date: '2025-12-01T12:00:00+05:30',
            pick_up_date_and_time: '2025-11-29T12:00:00+05:30',
            arrival_type: 1,
            departure_type: 1,
            no_of_nights: 2,
            no_of_days: 3,
            budget: 15000,
            entry_ticket_required: 0,
            guide_for_itinerary: 0,
            nationality: 101,
            food_type: 1,
            adult_count: 2,
            child_count: 0,
            infant_count: 0,
            special_instructions: '',
          },
          routes: [
            {
              itinerary_route_id: 19, // <-- UPDATE EXISTING ROUTE
              location_name: 'Chennai International Airport',
              next_visiting_location: 'Chennai',
              itinerary_route_date: '2025-11-29T00:00:00+05:30',
              no_of_days: 1,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
            {
              itinerary_route_id: 20, // <-- UPDATE EXISTING ROUTE
              location_name: 'Chennai',
              next_visiting_location: 'Pondicherry',
              itinerary_route_date: '2025-11-30T00:00:00+05:30',
              no_of_days: 2,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
            {
              itinerary_route_id: 21, // <-- UPDATE EXISTING ROUTE
              location_name: 'Pondicherry',
              next_visiting_location: 'Pondicherry',
              itinerary_route_date: '2025-12-01T00:00:00+05:30',
              no_of_days: 3,
              no_of_km: '',
              direct_to_next_visiting_place: 1,
              via_route: '',
            },
          ],
          vehicles: [
            {
              vehicle_details_id: 19879, // <-- UPDATE EXISTING VEHICLE ROW
              vehicle_type_id: 1,
              vehicle_count: 1,
            },
          ],
          travellers: [
            { room_id: 1, traveller_type: 1 },
            { room_id: 1, traveller_type: 1 },
          ],
        },
      },
    },
  })
  async createPlan(@Body() dto: CreateItineraryDto) {
    return this.svc.createPlan(dto);
  }

  
}
