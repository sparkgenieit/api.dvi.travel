// REPLACE-WHOLE-FILE
// FILE: src/modules/itineraries/engines/hotspot-engine.service.ts
// ✅ PHP PARITY HOTSPOT ENGINE (AUTO-SELECTION NEAR DESTINATION)
// ✅ NO GLOBAL "ALL HOTSPOTS" – FILTERS BY ROUTE LOCATION LIKE PHP

import { Injectable } from "@nestjs/common";
import { Prisma } from "@prisma/client";

type Tx = Prisma.TransactionClient;
type TimeLike = string | Date | number | null | undefined;

@Injectable()
export class HotspotEngineService {
  /* ---------- TIME HELPERS ---------- */

  private toSec(t: TimeLike): number {
    if (!t) return 0;
    if (t instanceof Date) {
      return (
        t.getHours() * 3600 + t.getMinutes() * 60 + t.getSeconds()
      );
    }
    if (typeof t === "number") return Math.floor(t);
    const parts = String(t).trim().split(":");
    const h = Number(parts[0] ?? "0") || 0;
    const m = Number(parts[1] ?? "0") || 0;
    const s = Number(parts[2] ?? "0") || 0;
    return h * 3600 + m * 60 + s;
  }

  // store as a Date-only-for-time (Prisma @db.Time is compatible with JS Date)
  private at(sec: number): Date {
    const d = new Date(1970, 0, 1, 0, 0, 0);
    d.setSeconds(sec);
    return d;
  }

  /* ---------- PUBLIC ENTRY ---------- */

  /**
   * Main entry used by itineraries.service.ts
   * - For each route in the plan:
   *   1) ensure hotspot rows exist (auto-select hotspots near destination)
   *   2) rebuild the start/end times as a continuous timeline
   */
  async rebuildRouteHotspots(planId: number, tx: Tx, userId: number) {
    const routes =
      await tx.dvi_itinerary_route_details.findMany({
        where: {
          itinerary_plan_ID: planId,
          deleted: 0,
          status: 1,
        },
        orderBy: { itinerary_route_ID: "asc" },
      });

    for (const route of routes) {
      await this.ensureHotspotsForRoute(tx, planId, route, userId);
      await this.rebuildTimelineForRoute(tx, planId, route);
    }
  }

  /* ---------- PHASE 1: INSERT HOTSPOTS (PHP-LIKE SELECTION) ---------- */

  /**
   * Auto-select hotspots for a given route, mimicking PHP:
   *
   * PHP SELECT (simplified):
   *   FROM dvi_hotspot_place
   *   LEFT JOIN dvi_hotspot_timing ON timing.hotspot_ID = place.hotspot_ID
   *   WHERE place.deleted = 0
   *     AND place.status = 1
   *     AND timing.hotspot_timing_day = $dayOfWeekNumeric
   *     AND (HOTSPOT_PLACE.hotspot_location LIKE '%$next_visiting_name%' ...)
   *
   * NestJS version below:
   * - Uses itinerary_route_date -> JS getDay() -> PHP day index
   * - Filters hotspot_location by next_visiting_location (destination),
   *   and optionally also by source_location.
   * - Only runs when there are NO item_type = 4 rows yet (so we don't duplicate
   *   if hotspots were already created/edited).
   */
  private async ensureHotspotsForRoute(
    tx: Tx,
    planId: number,
    route: any,
    userId: number,
  ) {
    // If there are already visit rows for this route, do not auto-create again
    const existingVisits =
      await tx.dvi_itinerary_route_hotspot_details.count({
        where: {
          itinerary_plan_ID: planId,
          itinerary_route_ID: route.itinerary_route_ID,
          item_type: 4, // visit segments
          deleted: 0,
        },
      });

    if (existingVisits > 0) {
      // PHP does a lot of UPDATE logic instead of blind re-insert;
      // since we’re in “auto-engine” mode, skip when user / previous logic
      // already created hotspots.
      return;
    }

    // --- Derive PHP's hotspot_timing_day from itinerary_route_date ---
    let jsDay = 0;
    if (route.itinerary_route_date instanceof Date) {
      jsDay = route.itinerary_route_date.getDay(); // 0 = Sun .. 6 = Sat
    }
    // PHP code uses its own weekday index; common pattern: Mon=0,...,Sun=6
    const phpDay = (jsDay + 6) % 7;

    // --- Figure out location filters (destination first, like PHP) ---
    const nextName = String(
      route.next_visiting_location ??
        route.next_visiting_name ??
        "",
    ).trim();

    const sourceName = String(
      route.source_location ?? route.source_name ?? "",
    ).trim();

    const orLocation: any[] = [];
    if (nextName) {
      orLocation.push({
        hotspot_location: { contains: nextName },
      });
    }
    if (sourceName) {
      orLocation.push({
        hotspot_location: { contains: sourceName },
      });
    }

    // If no text to filter by, don’t create anything
    if (!orLocation.length) return;

    // --- Find hotspots like the PHP query (raw SQL JOIN to avoid relation lookup) ---
    // Build dynamic WHERE for location filtering
    const locationLikes = orLocation.map(o => {
      if (o.hotspot_location?.contains) {
        return `p.hotspot_location LIKE '%${(o.hotspot_location.contains as string).replace(/'/g, "''")}'`;
      }
      return "";
    }).filter(Boolean);

    const locationFilter = locationLikes.length
      ? `AND (${locationLikes.join(" OR ")})`
      : "";

    const hotspots: any[] = await (tx as any).$queryRawUnsafe(`
      SELECT DISTINCT p.hotspot_ID, p.hotspot_type, p.hotspot_name, p.hotspot_description,
             p.hotspot_address, p.hotspot_landmark, p.hotspot_location, p.hotspot_priority,
             p.hotspot_adult_entry_cost, p.hotspot_child_entry_cost, p.hotspot_infant_entry_cost,
             p.hotspot_foreign_adult_entry_cost, p.hotspot_foreign_child_entry_cost,
             p.hotspot_foreign_infant_entry_cost, p.hotspot_duration, p.hotspot_rating,
             p.hotspot_latitude, p.hotspot_longitude, p.hotspot_video_url,
             p.createdby, p.createdon, p.updatedon, p.status, p.deleted
      FROM dvi_hotspot_place p
      INNER JOIN dvi_hotspot_timing t ON p.hotspot_ID = t.hotspot_ID
      WHERE p.deleted = 0
        AND p.status = 1
        AND t.hotspot_timing_day = ${phpDay}
        AND t.hotspot_closed = 0
        ${locationFilter}
      ORDER BY p.hotspot_priority ASC
    `);

    if (!hotspots.length) return;

    // --- Insert travel + visit pairs per hotspot, like your older engine ---
    for (const h of hotspots) {
      // Travel segment (item_type=3)
      await tx.dvi_itinerary_route_hotspot_details.create({
        data: {
          itinerary_plan_ID: planId,
          itinerary_route_ID: route.itinerary_route_ID,
          item_type: 3,
          hotspot_ID: h.hotspot_ID,
          // default 30 min travel if not overridden later
          hotspot_traveling_time: this.at(
            this.toSec("00:30:00"),
          ),
          itinerary_travel_type_buffer_time: this.at(
            this.toSec("00:00:00"),
          ),
          hotspot_travelling_distance: null,
          hotspot_amout: 0,
          hotspot_start_time: this.at(0),
          hotspot_end_time: this.at(0),
          allow_break_hours: 0,
          allow_via_route: 0,
          via_location_name: null,
          hotspot_plan_own_way: 0,
          status: 1,
          deleted: 0,
          createdby: userId,
        } as any,
      });

      // Visit segment (item_type=4)
      const visitDurSec = this.toSec(
        h.hotspot_duration ?? "01:00:00",
      );
      await tx.dvi_itinerary_route_hotspot_details.create({
        data: {
          itinerary_plan_ID: planId,
          itinerary_route_ID: route.itinerary_route_ID,
          item_type: 4,
          hotspot_ID: h.hotspot_ID,
          // in legacy schema, duration is stored in hotspot_traveling_time
          hotspot_traveling_time: this.at(visitDurSec),
          itinerary_travel_type_buffer_time: this.at(
            this.toSec("00:00:00"),
          ),
          hotspot_travelling_distance: null,
          hotspot_amout: 0,
          hotspot_start_time: this.at(0),
          hotspot_end_time: this.at(0),
          allow_break_hours: 0,
          allow_via_route: 0,
          via_location_name: null,
          hotspot_plan_own_way: 0,
          status: 1,
          deleted: 0,
          createdby: userId,
        } as any,
      });
    }
  }

  /* ---------- PHASE 2: BUILD CONTINUOUS TIMELINE ---------- */

  /**
   * Rebuilds hotspot_order + start/end times for:
   * - item_type = 1 (refresh/start-of-day)
   * - item_type = 3 (travel to hotspots)
   * - item_type = 4 (visit hotspots)
   * - item_type = 6 (return-to-hotel end marker)
   *
   * All other item_types (2,5,7, via-routes) are left untouched for now,
   * because their INSERT / UPDATE rules are highly conditional in PHP and
   * depend on many form branches.
   */
  private async rebuildTimelineForRoute(
    tx: Tx,
    planId: number,
    route: any,
  ) {
    // Base start time: route_start_time; fallback to 08:00 if missing
    let cursorSec = this.toSec(
      route.route_start_time ?? "08:00:00",
    );

    // Refresh duration (start-of-day buffer)
    const refreshSec = this.toSec(
      route.refresh_time ?? "01:00:00",
    );

    let order = 1;

    // ---------- 1) START / REFRESH ROW (item_type=1) ----------
    await tx.dvi_itinerary_route_hotspot_details.updateMany({
      where: {
        itinerary_plan_ID: planId,
        itinerary_route_ID: route.itinerary_route_ID,
        item_type: 1,
        deleted: 0,
      },
      data: {
        hotspot_order: order,
        hotspot_start_time: this.at(cursorSec),
        hotspot_end_time: this.at(cursorSec + refreshSec),
        hotspot_traveling_time: this.at(refreshSec),
        itinerary_travel_type_buffer_time: this.at(
          this.toSec("00:00:00"),
        ),
      },
    });

    cursorSec += refreshSec;
    order++;

    // ---------- 2) TRAVEL + VISIT PAIRS FOR HOTSPOTS ----------

    const visits =
      await tx.dvi_itinerary_route_hotspot_details.findMany({
        where: {
          itinerary_plan_ID: planId,
          itinerary_route_ID: route.itinerary_route_ID,
          item_type: 4, // visit rows
          deleted: 0,
        },
        orderBy: { route_hotspot_ID: "asc" },
      });

    for (const visit of visits) {
      // MATCHING TRAVEL ROW: same hotspot_ID, item_type=3
      const travel =
        await tx.dvi_itinerary_route_hotspot_details.findFirst(
          {
            where: {
              itinerary_plan_ID: planId,
              itinerary_route_ID: route.itinerary_route_ID,
              item_type: 3,
              hotspot_ID: visit.hotspot_ID,
              deleted: 0,
            },
            orderBy: { route_hotspot_ID: "asc" },
          },
        );

      // --- TRAVEL SEGMENT ---
      const travelDurSec = this.toSec(
        travel?.hotspot_traveling_time ?? "00:30:00",
      );
      if (travel) {
        await tx.dvi_itinerary_route_hotspot_details.update({
          where: {
            route_hotspot_ID: travel.route_hotspot_ID,
          },
          data: {
            hotspot_order: order,
            hotspot_start_time: this.at(cursorSec),
            hotspot_end_time: this.at(
              cursorSec + travelDurSec,
            ),
          },
        });
      }
      cursorSec += travelDurSec;
      order++;

      // --- VISIT SEGMENT ---
      const visitDurSec = this.toSec(
        visit.hotspot_traveling_time ?? "01:00:00",
      );
      await tx.dvi_itinerary_route_hotspot_details.update({
        where: {
          route_hotspot_ID: visit.route_hotspot_ID,
        },
        data: {
          hotspot_order: order,
          hotspot_start_time: this.at(cursorSec),
          hotspot_end_time: this.at(cursorSec + visitDurSec),
        },
      });

      cursorSec += visitDurSec;
      order++;
    }

    // ---------- 3) END-OF-DAY HOTEL RETURN (item_type=6) ----------
    await tx.dvi_itinerary_route_hotspot_details.updateMany({
      where: {
        itinerary_plan_ID: planId,
        itinerary_route_ID: route.itinerary_route_ID,
        item_type: 6,
        deleted: 0,
      },
      data: {
        hotspot_order: order,
        hotspot_start_time: this.at(cursorSec),
        hotspot_end_time: this.at(cursorSec),
        hotspot_traveling_time: this.at(
          this.toSec("00:00:00"),
        ),
        itinerary_travel_type_buffer_time: this.at(
          this.toSec("00:00:00"),
        ),
      },
    });
  }
}
