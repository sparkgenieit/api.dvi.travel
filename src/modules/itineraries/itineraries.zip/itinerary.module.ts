import { Module } from '@nestjs/common';
import { ItinerariesController } from './itineraries.controller';
import { ItinerariesService } from './itineraries.service';
import { PrismaService } from '../../prisma.service';
import { ItineraryHotspotsEngine } from "./engines/itinerary-hotspots.engine";
import { ItineraryVehiclesEngine } from "./engines/itinerary-vehicles.engine";

@Module({
  
  controllers: [ItinerariesController],
  providers: [ItinerariesService, PrismaService,    ItineraryHotspotsEngine,  // ✅ ADD THIS
    ItineraryVehiclesEngine]
  
})
export class ItinerariesModule {}
