// REPLACE-WHOLE-FILE
// FILE: src/itineraries/itineraries.module.ts

import { Module } from "@nestjs/common";
import { PrismaService } from "../prisma.service";
import { ItinerariesController } from "./itineraries.controller";
import { ItinerariesService } from "./itineraries.service";
import { QuoteIdService } from "./quote-id.service";
import { PlanEngineService } from "./engines/plan-engine.service";
import { RouteEngineService } from "./engines/route-engine.service";
import { HotspotEngineService } from "./engines/hotspot-engine.service";
import { HotelEngineService } from "./engines/hotel-engine.service";
import { TravellersEngineService } from "./engines/travellers-engine.service";
import { VehiclesEngineService } from "./engines/vehicles-engine.service";
import { ItineraryDetailsService } from "./details/itinerary-details.service";
import { ItineraryHotelDetailsService } from "./details/itinerary-hotel-details.service";

@Module({
  controllers: [ItinerariesController],
  providers: [
    PrismaService,
    ItinerariesService,
    QuoteIdService,
    PlanEngineService,
    RouteEngineService,
    HotspotEngineService,
    HotelEngineService,
    TravellersEngineService,
    VehiclesEngineService,
    ItineraryDetailsService,
    ItineraryHotelDetailsService,
  ],
  exports: [ItinerariesService],
})
export class ItinerariesModule {}
