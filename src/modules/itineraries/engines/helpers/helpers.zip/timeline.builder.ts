// REPLACE-WHOLE-FILE
// FILE: src/modules/itineraries/engines/helpers/timeline.builder.ts
//
// PURPOSE:
//   Orchestrate building rows for:
//     • dvi_itinerary_route_hotspot_details
//     • dvi_itinerary_route_hotspot_parking_charge
//   using the helper builders.
//
// IMPORTANT:
//   - This is a PHP-parity-oriented skeleton, not final parity.
//   - You MUST plug in the real “selected hotspots per route” table
//     and the real “hotel location per route” query where marked TODO.
//   - It keeps createdByUserId = 1 to avoid changing other services.
//     Later you can pass the real user id from controller → service → engine.

import { Prisma } from "@prisma/client";
import { HotspotDetailRow } from "./types";
import { RefreshmentBuilder } from "./refreshment.builder";
import { TravelSegmentBuilder } from "./travel-segment.builder";
import { HotspotSegmentBuilder } from "./hotspot-segment.builder";
import { HotelTravelBuilder } from "./hotel-travel.builder";
import { ReturnSegmentBuilder } from "./return-segment.builder";
import {
  ParkingChargeBuilder,
  ParkingChargeRow,
} from "./parking-charge.builder";

type Tx = Prisma.TransactionClient;

interface PlanHeader {
  itinerary_plan_ID: number;
  trip_start_date: Date;
  trip_end_date: Date;
  pick_up_date_and_time: Date;
  arrival_type: number;
  departure_type: number;
  entry_ticket_required: number;
  nationality: number;
  total_adult: number;
  total_children: number;
  total_infants: number;
  itinerary_preference: number;
  departure_location?: string | null;
}

interface RouteRow {
  itinerary_route_ID: number;
  itinerary_plan_ID: number;
  itinerary_route_date: Date;
  route_start_time: string;
  route_end_time: string;
  location_name: string | null;
  next_visiting_location: string | null;
  location_id: number | null;
}

// Minimal view of a selected hotspot row.
// ⚠️ You MUST adjust table/field names in fetchSelectedHotspotsForRoute().
interface SelectedHotspot {
  hotspot_ID: number;
  display_order?: number;
}

export class TimelineBuilder {
  private readonly refreshmentBuilder = new RefreshmentBuilder();
  private readonly travelBuilder = new TravelSegmentBuilder();
  private readonly hotspotBuilder = new HotspotSegmentBuilder();
  private readonly hotelBuilder = new HotelTravelBuilder();
  private readonly returnBuilder = new ReturnSegmentBuilder();
  private readonly parkingBuilder = new ParkingChargeBuilder();

  /**
   * Main orchestrator for one plan.
   * Returns in-memory arrays that hotspot-engine.service.ts will insert.
   */
  async buildTimelineForPlan(
    tx: Tx,
    planId: number,
  ): Promise<{ hotspotRows: HotspotDetailRow[]; parkingRows: ParkingChargeRow[] }> {
    const plan = (await (tx as any).dvi_itinerary_plan_details.findFirst({
      where: { itinerary_plan_ID: planId, deleted: 0 },
    })) as PlanHeader | null;

    if (!plan) {
      return { hotspotRows: [], parkingRows: [] };
    }

    const routes = (await (tx as any).dvi_itinerary_route_details.findMany({
      where: { itinerary_plan_ID: planId, deleted: 0, status: 1 },
      orderBy: [
        { itinerary_route_date: "asc" },
        { itinerary_route_ID: "asc" },
      ],
    })) as RouteRow[];

    if (!routes.length) {
      return { hotspotRows: [], parkingRows: [] };
    }

    const hotspotRows: HotspotDetailRow[] = [];
    const parkingRows: ParkingChargeRow[] = [];

    // TODO (later): pass real user id from controller/service.
    const createdByUserId = 1;

    for (const route of routes) {
      let order = 1;
      let currentTime = route.route_start_time;

      // Maintain current logical location name for distance calculations.
      // Start with the route's location_name (same as PHP "route start city").
      let currentLocationName: string =
        (route.location_name as string) ||
        (route.next_visiting_location as string) ||
        (plan.departure_location as string) ||
        "";

      // 1) REFRESHMENT SEGMENT (item_type = 1) at route start
      // In PHP this is often a fixed 1-hour break (or from settings).
      const breakDuration = "01:00:00"; // HH:MM:SS – adjust if you read from global settings.

      const { row: refreshRow, nextTime: tAfterBreak } =
        this.refreshmentBuilder.build(
          planId,
          route.itinerary_route_ID,
          order++,
          currentTime,
          breakDuration,
          createdByUserId,
        );

      hotspotRows.push(refreshRow);
      currentTime = tAfterBreak;
      // currentLocationName stays the same (they didn't travel).

      // 2) SELECTED HOTSPOTS FOR THIS ROUTE
      const selectedHotspots = await this.fetchSelectedHotspotsForRoute(
        tx,
        planId,
        route.itinerary_route_ID,
      );

      console.log(
        `[Timeline] Route ${route.itinerary_route_ID}: Selected ${selectedHotspots.length} hotspots`,
      );

      // Build travel + hotspot segments in order.
      for (const sh of selectedHotspots) {
        console.log(
          `[Timeline] Processing hotspot ${sh.hotspot_ID} for route ${route.itinerary_route_ID}`,
        );

        // 2.a) Find the "city name" or suitable location name of this hotspot.
        const hotspotLocationName =
          (await this.getHotspotLocationName(tx, sh.hotspot_ID)) ||
          // fallback: use next_visiting_location if nothing else
          (route.next_visiting_location as string) ||
          currentLocationName;

        // 2.b) TRAVEL SEGMENT (item_type = 3) from currentLocationName → hotspotLocationName
        const { row: travelRow, nextTime: tToHotspot } =
          await this.travelBuilder.buildTravelSegment(tx, {
            planId,
            routeId: route.itinerary_route_ID,
            order: order++,
            item_type: 3, // Site Seeing Traveling
            travelLocationType: 1, // TODO: derive local vs outstation (1/2) if you have state info.
            startTime: currentTime,
            userId: createdByUserId,
            sourceLocationName: currentLocationName,
            destinationLocationName: hotspotLocationName,
          });

        hotspotRows.push(travelRow);
        currentTime = tToHotspot;
        currentLocationName = hotspotLocationName;

        // 2.c) HOTSPOT STAY SEGMENT (item_type = 4)
        console.log(
          `[Timeline] Building hotspot row for hotspot_ID=${sh.hotspot_ID}`,
        );
        const { row: hotspotRow, nextTime: tAfterHotspot } =
          await this.hotspotBuilder.build(tx, {
            planId,
            routeId: route.itinerary_route_ID,
            order: order++,
            hotspotId: sh.hotspot_ID,
            startTime: currentTime,
            userId: createdByUserId,
            totalAdult: plan.total_adult,
            totalChildren: plan.total_children,
            totalInfants: plan.total_infants,
            nationality: plan.nationality,
            itineraryPreference: plan.itinerary_preference,
          });

        console.log(
          `[Timeline] Built hotspot row: item_type=${hotspotRow.item_type}, hotspot_ID=${hotspotRow.hotspot_ID}, order=${hotspotRow.hotspot_order}`,
        );

        hotspotRows.push(hotspotRow);
        currentTime = tAfterHotspot;
        // currentLocationName remains at the hotspot.

        // 2.d) PARKING CHARGE ROW for this hotspot (if a master row exists)
        const parking = await this.parkingBuilder.buildForHotspot(tx, {
          planId,
          routeId: route.itinerary_route_ID,
          hotspotId: sh.hotspot_ID,
          userId: createdByUserId,
        });

        if (parking) {
          parkingRows.push(parking);
        }
      }

      // 3) TRAVEL TO HOTEL (item_type = 5)
      // In PHP this uses the chosen hotel for that route/date.
      const hotelLocationName =
        (await this.getHotelLocationNameForRoute(
          tx,
          planId,
          route.itinerary_route_ID,
        )) ||
        (route.next_visiting_location as string) ||
        currentLocationName;

      const { row: toHotelRow, nextTime: tAfterHotel } =
        await this.hotelBuilder.buildToHotel(tx, {
          planId,
          routeId: route.itinerary_route_ID,
          order: order++,
          startTime: currentTime,
          travelLocationType: 1, // TODO: local vs outstation if needed
          userId: createdByUserId,
          sourceLocationName: currentLocationName,
          destinationLocationName: hotelLocationName,
        });

      hotspotRows.push(toHotelRow);
      currentTime = tAfterHotel;
      currentLocationName = hotelLocationName;

      // 4) RETURN / CLOSING ROW FOR HOTEL (item_type = 6)
      // PHP usually creates a closing row with 0 distance/time.
      const { row: closeHotelRow, nextTime: tClose } =
        await this.hotelBuilder.buildReturnToHotel(tx, {
          planId,
          routeId: route.itinerary_route_ID,
          order: order++,
          startTime: currentTime,
          userId: createdByUserId,
        });

      hotspotRows.push(closeHotelRow);
      currentTime = tClose;
      // currentLocationName stays at hotel.

      // 5) LAST ROUTE ONLY → RETURN TO DEPARTURE LOCATION (item_type = 7)
      const isLastRoute = await this.isLastRouteOfPlan(
        tx,
        planId,
        route.itinerary_route_ID,
      );

      if (isLastRoute) {
        const { row: returnRow, nextTime: tAfterReturn } =
          await this.returnBuilder.buildReturnToDeparture(tx, {
            planId,
            routeId: route.itinerary_route_ID,
            order: order++,
            startTime: currentTime,
            travelLocationType: 2, // outstation by default
            userId: createdByUserId,
            currentLocationName,
          });

        hotspotRows.push(returnRow);
        currentTime = tAfterReturn;
        currentLocationName = plan.departure_location as string;
      }
    }

    console.log(
      `[Timeline] Returning ${hotspotRows.length} hotspot rows and ${parkingRows.length} parking rows`,
    );
    console.log(
      `[Timeline] Hotspot rows item_types: ${hotspotRows.map((r) => r.item_type).join(", ")}`,
    );
    console.log(
      `[Timeline] Hotspot rows hotspot_IDs: ${hotspotRows.map((r) => r.hotspot_ID).join(", ")}`,
    );

    return { hotspotRows, parkingRows };
  }

  /**
   * Decide if this is the last route of the plan (used for item_type = 7).
   */
  private async isLastRouteOfPlan(
    tx: Tx,
    planId: number,
    routeId: number,
  ): Promise<boolean> {
    const last = await (tx as any).dvi_itinerary_route_details.findFirst({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      orderBy: [
        { itinerary_route_date: "desc" },
        { itinerary_route_ID: "desc" },
      ],
    });

    if (!last) return false;
    return last.itinerary_route_ID === routeId;
  }

  /**
   * Fetch available hotspots for a given route location.
   *
   * In PHP: the `includeHotspotInItinerary()` function is called for each hotspot
   * that is available at the route's location, in priority order.
   *
   * We replicate this by:
   * 1. Get the route's location_name or next_visiting_location
   * 2. Query dvi_hotspot_place for hotspots matching that location (by name)
   * 3. Return them sorted by priority
   *
   * NOTE: In the schema, dvi_hotspot_place doesn't have a location_id field.
   * Instead, it has hotspot_location (text) which must be matched against
   * the route's location_name or next_visiting_location.
   */
  private async fetchSelectedHotspotsForRoute(
    tx: Tx,
    planId: number,
    routeId: number,
  ): Promise<SelectedHotspot[]> {
    try {
      // Get route details to find the location name
      const route = (await (tx as any).dvi_itinerary_route_details?.findFirst({
        where: {
          itinerary_plan_ID: planId,
          itinerary_route_ID: routeId,
          deleted: 0,
          status: 1,
        },
      })) as RouteRow | null;

      if (!route) {
        console.log(
          `[fetchSelectedHotspots] Route not found for plan ${planId}, route ${routeId}`,
        );
        return [];
      }

      // Use location_name from route, or fallback to next_visiting_location
      const targetLocation =
        (route.location_name as string) ||
        (route.next_visiting_location as string);

      if (!targetLocation) {
        console.log(
          `[fetchSelectedHotspots] No location name found for route ${routeId}`,
        );
        return [];
      }

      console.log(
        `[fetchSelectedHotspots] Fetching hotspots for route ${routeId}, location: "${targetLocation}"`,
      );

      // Fetch ALL active hotspots first, then filter in memory
      // (Prisma string matching with contains can be unreliable)
      const allHotspots =
        (await (tx as any).dvi_hotspot_place?.findMany({
          where: {
            deleted: 0,
            status: 1,
          },
          orderBy: [
            { hotspot_priority: "asc" },
            { hotspot_ID: "asc" },
          ],
        })) || [];

      console.log(
        `[fetchSelectedHotspots] Found ${allHotspots.length} total active hotspots`,
      );

      // Filter hotspots that match the location (case-insensitive)
      const matchingHotspots = allHotspots.filter((h: any) => {
        const hsLocation = (h.hotspot_location as string) || "";
        const matches = hsLocation
          .toLowerCase()
          .includes(targetLocation.toLowerCase());
        if (matches) {
          console.log(
            `[fetchSelectedHotspots] Matched hotspot ${h.hotspot_ID}: "${hsLocation}"`,
          );
        }
        return matches;
      });

      console.log(
        `[fetchSelectedHotspots] Matched ${matchingHotspots.length} hotspots for location "${targetLocation}"`,
      );

      return matchingHotspots.map((h: any, index: number) => ({
        hotspot_ID: Number(h.hotspot_ID ?? 0) || 0,
        display_order: Number(h.hotspot_priority ?? index + 1) || index + 1,
      }));
    } catch (err) {
      // If query fails (table missing, etc.), return empty array
      // This means no hotspots will be auto-included for this route
      console.error("[fetchSelectedHotspots] Error:", err);
      return [];
    }
  }

  /**
   * Get the "location name" (city) of a hotspot.
   *
   * In PHP, this is whatever you used in getSTOREDLOCATION_ID_FROM_SOURCE_AND_DESTINATION
   * when travelling to a hotspot.
   *
   * TODO: Adjust the field you return:
   *   - hotspot_location
   *   - hotspot_city
   *   - city
   *   - etc. depending on your dvi_hotspot_place schema.
   */
  private async getHotspotLocationName(
    tx: Tx,
    hotspotId: number,
  ): Promise<string | null> {
    if (!hotspotId) return null;

    const hs = await (tx as any).dvi_hotspot_place?.findFirst({
      where: { hotspot_ID: hotspotId, deleted: 0, status: 1 },
    });

    if (!hs) return null;

    return (
      hs.hotspot_location ??
      hs.hotspot_city ??
      hs.city ??
      hs.location_name ??
      null
    );
  }

  /**
   * Get the hotel city/location used for travel-to-hotel segment for a route.
   *
   * In PHP, this comes from your big hotel-selection query joining:
   *   dvi_itinerary_route_details + dvi_stored_locations + dvi_hotel + dvi_hotel_rooms
   *
   * TODO: Replace this placeholder with the real query and returned city field.
   */
  private async getHotelLocationNameForRoute(
    tx: Tx,
    planId: number,
    routeId: number,
  ): Promise<string | null> {
    // Example placeholder:
    //  - It tries to find a hotel row for this plan/route/date and returns
    //    hotel_city_name (adjust field names).
    const hotel = await (tx as any).dvi_itinerary_plan_hotel_details?.findFirst(
      {
        where: {
          itinerary_plan_id: planId,
          itinerary_route_id: routeId,
          deleted: 0,
          status: 1,
        },
      },
    );

    if (!hotel) return null;

    const h = hotel.hotel || hotel;

    return (
      h.hotel_city ??
      h.city ??
      h.hotel_location ??
      h.hotel_name ??
      null
    );
  }
}
