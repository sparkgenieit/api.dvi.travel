// FILE: src/modules/itineraries/engines/helpers/distance.helper.ts

import { Prisma } from "@prisma/client";
import { minutesToTime } from "./time.helper";

type Tx = Prisma.TransactionClient;

export interface DistanceResult {
  distanceKm: number;      // e.g. 8.42
  travelTime: string;      // HH:MM:SS
  bufferTime: string;      // HH:MM:SS
}

/**
 * Wraps distance + duration + buffer calculation using:
 *  - dvi_stored_locations.distance / duration
 *  - dvi_global_settings.itinerary_* fields
 *
 * This is where you mirror PHP's calculateDistanceAndDuration().
 */
export class DistanceHelper {
  /**
   * Use stored_locations row directly (when you already know location_ID).
   */
  async fromLocationId(
    tx: Tx,
    locationId: number,
    travelLocationType: 1 | 2, // 1=local, 2=outstation
  ): Promise<DistanceResult> {
    const loc = await (tx as any).dvi_stored_locations.findFirst({
      where: { location_ID: locationId },
    });

    if (!loc) {
      // Fallback: no row, zero distance/time.
      return {
        distanceKm: 0,
        travelTime: "00:00:00",
        bufferTime: "00:00:00",
      };
    }

    const distance = Number(loc.distance ?? 0);
    // loc.duration might be in minutes or "HH:MM:SS" – adapt if needed.
    const rawDuration = Number(loc.duration ?? 0);
    const travelTime = minutesToTime(rawDuration); // adjust if your duration is already HH:MM:SS

    const bufferTime = await this.getBufferTime(tx, travelLocationType);

    return {
      distanceKm: distance,
      travelTime,
      bufferTime,
    };
  }

  /**
   * When you have source/dest names (cities/locations) instead of location_ID.
   * Mirrors getSTOREDLOCATION_ID_FROM_SOURCE_AND_DESTINATION.
   */
  async fromSourceAndDestination(
    tx: Tx,
    sourceLocation: string,
    destinationLocation: string,
    travelLocationType: 1 | 2,
  ): Promise<DistanceResult> {
    const loc = await (tx as any).dvi_stored_locations.findFirst({
      where: {
        source_location: sourceLocation,
        destination_location: destinationLocation,
      },
    });

    if (!loc) {
      return {
        distanceKm: 0,
        travelTime: "00:00:00",
        bufferTime: await this.getBufferTime(tx, travelLocationType),
      };
    }

    const distance = Number(loc.distance ?? 0);
    const rawDuration = Number(loc.duration ?? 0);
    const travelTime = minutesToTime(rawDuration);

    const bufferTime = await this.getBufferTime(tx, travelLocationType);

    return {
      distanceKm: distance,
      travelTime,
      bufferTime,
    };
  }

  private async getBufferTime(
    tx: Tx,
    travelLocationType: 1 | 2,
  ): Promise<string> {
    // TODO: adjust field names to match your dvi_global_settings model.
    const gs = await (tx as any).dvi_global_settings.findFirst({
      where: { deleted: 0, status: 1 },
    });

    if (!gs) return "00:00:00";

    const minutes =
      travelLocationType === 1
        ? Number(gs.itinerary_local_buffer_time ?? 0)
        : Number(gs.itinerary_outstation_buffer_time ?? 0);

    return minutesToTime(minutes);
  }
}
