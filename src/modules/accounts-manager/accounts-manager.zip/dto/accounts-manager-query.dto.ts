import { IsIn, IsOptional, IsString } from "class-validator";

export type AccountsManagerStatus = "all" | "paid" | "due";

/**
 * Component type values the UI and backend both understand.
 * "flight" is kept to match the current UI dropdown, but right now
 * you may only have real data for hotel / vehicle / guide / hotspot / activity.
 */
export type AccountsManagerComponentType =
  | "all"
  | "guide"
  | "hotspot"
  | "activity"
  | "hotel"
  | "vehicle"
  | "flight";

export const ACCOUNT_STATUS_VALUES: AccountsManagerStatus[] = [
  "all",
  "paid",
  "due",
];

export const ACCOUNT_COMPONENT_TYPE_VALUES: AccountsManagerComponentType[] = [
  "all",
  "guide",
  "hotspot",
  "activity",
  "hotel",
  "vehicle",
  "flight",
];

/**
 * Query DTO for GET /accounts-manager
 * Matches the frontend fetchAccountsFromApi(params) in AccountsManager.tsx
 */
export class AccountsManagerQueryDto {
  /**
   * Tab status filter: "all" | "paid" | "due"
   * If omitted, defaults to "all" in the service.
   */
  @IsOptional()
  @IsIn(ACCOUNT_STATUS_VALUES)
  status?: AccountsManagerStatus;

  /**
   * Component type filter: "all" | "hotel" | "vehicle" | "guide" | "hotspot" | "activity" | "flight"
   * If omitted, defaults to "all" in the service.
   */
  @IsOptional()
  @IsIn(ACCOUNT_COMPONENT_TYPE_VALUES)
  componentType?: AccountsManagerComponentType;

  /** Quote ID search (free text, from the "Quote ID" filter box) */
  @IsOptional()
  @IsString()
  quoteId?: string;

  /**
   * From Date, as string in DD/MM/YYYY (UI sends exactly this format)
   * Used as lower bound on trip date (start/end).
   */
  @IsOptional()
  @IsString()
  fromDate?: string;

  /**
   * To Date, as string in DD/MM/YYYY
   * Used as upper bound on trip date (start/end).
   */
  @IsOptional()
  @IsString()
  toDate?: string;

  /**
   * Agent name (selected from dynamic Agent dropdown in the UI)
   * Should match the "agent" field in row data.
   */
  @IsOptional()
  @IsString()
  agent?: string;

  /**
   * Free-text search that checks quoteId + component name + agent.
   * This comes from the top-right "Search..." box in the table header.
   */
  @IsOptional()
  @IsString()
  search?: string;
}
