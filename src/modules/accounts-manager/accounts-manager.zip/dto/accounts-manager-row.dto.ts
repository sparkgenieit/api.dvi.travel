export type AccountsManagerRowStatus = "paid" | "due";

export type AccountsManagerRowComponentType =
  | "guide"
  | "hotspot"
  | "activity"
  | "hotel"
  | "vehicle";

export class AccountsManagerRowDto {
  id: number;

  // itinerary_quote_ID from dvi_accounts_itinerary_details
  quoteId: string;

  // vendor / component name (hotel, guide, hotspot, activity, vehicle)
  hotelName: string;

  // amounts from *_details tables
  amount: number;  // total_payable
  payout: number;  // total_paid
  payable: number; // total_balance

  status: AccountsManagerRowStatus; // 'paid' or 'due'

  componentType?: AccountsManagerRowComponentType;

  // additional info used by filters
  agent?: string;
  startDate?: string; // DD/MM/YYYY
  endDate?: string;   // DD/MM/YYYY
}
