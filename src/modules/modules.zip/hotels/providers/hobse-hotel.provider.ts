import { Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import axios, { AxiosInstance } from 'axios';
import { PrismaService } from '../../../prisma.service';
import {
  IHotelProvider,
  HotelSearchResult,
  RoomType,
  HotelSearchCriteria,
  HotelPreferences,
  HotelConfirmationDTO,
  HotelConfirmationResult,
  HotelConfirmationDetails,
  CancellationResult,
} from '../interfaces/hotel-provider.interface';

interface HobseWrapperRequest {
  hobse: {
    version: string;
    datetime: string;
    clientToken: string;
    accessToken: string;
    productToken: string;
    request: {
      method: string;
      data: any;
    };
  };
}

interface HobseWrapperResponse {
  hobse: {
    version: string;
    datetime: string;
    response: {
      status: {
        success: string;
        code: string;
        message: string;
      };
      totalRecords: number;
      data: any;
    };
    request: any;
  };
}

@Injectable()
export class HobseHotelProvider implements IHotelProvider {
  // Postman calls: https://api.hobse.com/v1/qa/htl/<MethodName>
  // and sends form-data key "params" = JSON string wrapper.
  private readonly BASE_URL = process.env.HOBSE_BASE_URL || 'https://api.hobse.com/v1/qa/htl';
  private readonly CLIENT_TOKEN = process.env.HOBSE_CLIENT_TOKEN || '';
  private readonly ACCESS_TOKEN = process.env.HOBSE_ACCESS_TOKEN || '';
  private readonly PRODUCT_TOKEN = process.env.HOBSE_PRODUCT_TOKEN || '';

  // Required by GetAvailableRoomTariff / CalculateReservationCost (per your examples)
  private readonly PARTNER_ID = process.env.HOBSE_PARTNER_ID || '';
  private readonly PARTNER_TYPE_ID = process.env.HOBSE_PARTNER_TYPE_ID || '';
  private readonly PRICE_OWNER_TYPE = process.env.HOBSE_PRICE_OWNER_TYPE || '2';
  private readonly TARIFF_MODE = process.env.HOBSE_TARIFF_MODE || 'B2B';
  private readonly PARTNER_TYPE = process.env.HOBSE_PARTNER_TYPE || 'TA';

  private logger = new Logger(HobseHotelProvider.name);
  private http: AxiosInstance = axios;

  constructor(private readonly prisma: PrismaService) {
    this.logger.log('🏨 HOBSE Hotel Provider initialized');
    this.logger.log(`Using endpoint: ${this.BASE_URL}`);
  }

  getName(): string {
    return 'HOBSE';
  }

  private buildWrapper(method: string, data: any): HobseWrapperRequest {
    return {
      hobse: {
        version: '1.0',
        datetime: new Date().toISOString().replace('Z', '+05:30'),
        clientToken: this.CLIENT_TOKEN,
        accessToken: this.ACCESS_TOKEN,
        productToken: this.PRODUCT_TOKEN,
        request: {
          method,
          data: {
            ...data,
            resultType: 'json',
          },
        },
      },
    };
  }

  /**
   * HOBSE expects: form-data key "params" containing JSON string of wrapper.
   * We send it as x-www-form-urlencoded (single field "params") which behaves like Postman "form-data params".
   */
  private async post(endpoint: string, method: string, data: any): Promise<HobseWrapperResponse> {
    try {
      const url = `${this.BASE_URL}/${endpoint}`;
      const wrapper = this.buildWrapper(method, data);

      const body = new URLSearchParams();
      body.append('params', JSON.stringify(wrapper));

      const response = await this.http.post<HobseWrapperResponse>(url, body.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 30000,
      });

      const ok = response.data?.hobse?.response?.status?.success === 'true';
      if (!ok) {
        const msg = response.data?.hobse?.response?.status?.message || 'Unknown error';
        throw new Error(msg);
      }

      return response.data;
    } catch (error: any) {
      const msg = error?.message || 'Unknown error';
      this.logger.error(`❌ HOBSE API Error (${endpoint}): ${msg}`);
      throw new InternalServerErrorException(`HOBSE API failed: ${msg}`);
    }
  }

  /**
   * SEARCH
   * criteria.cityCode here is your itinerary flow code (usually TBO city code).
   * We map it to dvi_cities.hobse_city_code + city name (for filtering GetHotelList by cityName).
   */
  async search(criteria: HotelSearchCriteria, _preferences?: HotelPreferences): Promise<HotelSearchResult[]> {
    try {
      this.logger.log(`\n   📡 HOBSE SEARCH: cityCode=${criteria.cityCode}, ${criteria.checkInDate}→${criteria.checkOutDate}`);

      const cityRow = await this.prisma.dvi_cities.findFirst({
        where: {
          OR: [{ tbo_city_code: criteria.cityCode }, { hobse_city_code: criteria.cityCode }],
        },
        select: { name: true, hobse_city_code: true },
      });

      if (!cityRow?.hobse_city_code || !cityRow?.name) {
        this.logger.warn(`   ⚠️  No HOBSE mapping for cityCode: ${criteria.cityCode}`);
        return [];
      }

      // Get FULL hotel list, then filter by cityName
      const listResp = await this.post('GetHotelList', 'htl/GetHotelList', {});
      const allHotels: any[] = Array.isArray(listResp?.hobse?.response?.data) ? listResp.hobse.response.data : [];

      const cityNameLower = cityRow.name.toLowerCase();
      const cityHotels = allHotels.filter((h) => (h?.cityName || '').toLowerCase() === cityNameLower);

      if (cityHotels.length === 0) {
        this.logger.warn(`   📭 No HOBSE hotels found for city: ${cityRow.name}`);
        return [];
      }

      const results: HotelSearchResult[] = [];

      // limited concurrency
      const concurrency = 5;
      for (let i = 0; i < cityHotels.length; i += concurrency) {
        const slice = cityHotels.slice(i, i + concurrency);

        const chunk = await Promise.all(
          slice.map((h) =>
            this.getHotelTariffAsSearchResult({
              hobseCityId: cityRow.hobse_city_code!,
              hotelId: h.hotelId,
              hotelName: h.hotelName,
              starCategory: h.starCategory,
              address: h.address,
              criteria,
            }).catch((e) => {
              this.logger.error(`   ❌ Tariff failed for hotel ${h?.hotelId}: ${e?.message || e}`);
              return null;
            }),
          ),
        );

        chunk.filter(Boolean).forEach((x) => results.push(x as HotelSearchResult));
      }

      this.logger.log(`   ✅ HOBSE: returning ${results.length}/${cityHotels.length} hotels with tariffs`);
      return results;
    } catch (error: any) {
      this.logger.error(`   ❌ HOBSE search error: ${error?.message || error}`);
      return [];
    }
  }

  private async getHotelTariffAsSearchResult(args: {
    hobseCityId: string;
    hotelId: string;
    hotelName: string;
    starCategory?: string;
    address?: string;
    criteria: HotelSearchCriteria;
  }): Promise<HotelSearchResult | null> {
    const { hobseCityId, hotelId, hotelName, starCategory, address, criteria } = args;

    const sessionId = `DVI-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    const adultCount = String(Math.max(1, criteria.guestCount || 2));
    const roomData = [{ adultCount, childCount: '0', infantCount: '0' }];

    const req = {
      sessionId,
      fromDate: criteria.checkInDate,
      toDate: criteria.checkOutDate,
      cityId: String(hobseCityId),
      priceOwnerType: String(this.PRICE_OWNER_TYPE),
      partnerId: String(this.PARTNER_ID),
      partnerTypeId: String(this.PARTNER_TYPE_ID),
      tariffMode: String(this.TARIFF_MODE),
      roomData,
      hotelFilter: [{ hotelId }],
    };

    const tariffResp = await this.post('GetAvailableRoomTariff', 'htl/GetAvailableRoomTariff', req);
    const payload = tariffResp?.hobse?.response?.data;

    const list = Array.isArray(payload) ? payload : [];
    if (!Array.isArray(payload) || list.length === 0) return null;

    const hotelTariff = list[0];
    const roomOptions: any[] = Array.isArray(hotelTariff?.roomOptions) ? hotelTariff.roomOptions : [];
    if (roomOptions.length === 0) return null;

    let minPrice = Number.POSITIVE_INFINITY;
    let bestOption: any = null;

    const roomTypes: RoomType[] = [];

    for (const opt of roomOptions) {
      const ratesData = Array.isArray(opt?.ratesData) ? opt.ratesData : [];
      const firstRate = ratesData[0] || {};

      const priceStr = firstRate?.roomCost ?? firstRate?.totalCostWithTax ?? firstRate?.totalCost ?? '0';
      const price = parseFloat(String(priceStr)) || 0;

      if (price > 0 && price < minPrice) {
        minPrice = price;
        bestOption = opt;
      }

      roomTypes.push({
        roomCode: opt.roomCode || '',
        roomName: opt.roomName || opt.roomDesc || 'Room',
        bedType: opt.occupancyTypeName || 'Standard',
        capacity: Number(firstRate?.totalPax || criteria.guestCount || 2),
        price,
        cancellationPolicy: '',
      });
    }

    if (!bestOption || !isFinite(minPrice) || minPrice <= 0) return null;

    const roomTypeName = bestOption?.roomName || bestOption?.roomDesc || '';
    const mealPlan = bestOption?.ratePlanName || bestOption?.ratePlanDesc || '-';

    return {
      provider: 'HOBSE',
      hotelCode: hotelId,
      hotelName: hotelName || 'HOBSE Hotel',
      cityCode: criteria.cityCode,
      address: address || '',
      rating: parseInt(String(starCategory || hotelTariff?.starCategory || '0'), 10) || 0,
      category: starCategory ? `${starCategory}-Star` : '',
      facilities: [],
      images: [],
      price: minPrice,
      currency: hotelTariff?.currencyCode || 'INR',
      roomTypes,
      roomType: roomTypeName,
      mealPlan,
      searchReference: JSON.stringify({
        provider: 'HOBSE',
        hotelId,
        cityId: hobseCityId,
        checkInDate: criteria.checkInDate,
        checkOutDate: criteria.checkOutDate,
        priceOwnerType: this.PRICE_OWNER_TYPE,
        partnerId: this.PARTNER_ID,
        partnerTypeId: this.PARTNER_TYPE_ID,
        tariffMode: this.TARIFF_MODE,
        roomCode: bestOption?.roomCode,
        occupancyTypeCode: bestOption?.occupancyTypeCode,
        ratePlanCode: bestOption?.ratePlanCode,
      }),
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    };
  }

  // Not needed for hotel listing endpoint right now
  async getConfirmation(_confirmationRef: string): Promise<HotelConfirmationDetails> {
    throw new InternalServerErrorException('HOBSE confirmation not implemented');
  }

  async confirmBooking(_bookingDetails: HotelConfirmationDTO): Promise<HotelConfirmationResult> {
    throw new InternalServerErrorException('HOBSE booking not implemented');
  }

  async cancelBooking(_confirmationRef: string, _reason: string): Promise<CancellationResult> {
    throw new InternalServerErrorException('HOBSE cancel not implemented');
  }
}
