export const ITEM_REFRESH = 1; // PHP-like “refresh/buffer” row
export const ITEM_TRAVEL_OR_BREAK = 3; // travel row (allow_break_hours=0) OR break row (allow_break_hours=1)
export const ITEM_VISIT = 4; // visit row
export const ITEM_RETURN_TRAVEL = 5; // return travel to destination
export const ITEM_END_BUFFER = 6; // end buffer/marker
export const PREF_HOTEL = 1;
export const PREF_VEHICLE = 2;
export const PREF_BOTH = 3;
