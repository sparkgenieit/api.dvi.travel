export enum SwaggerRole {
  admin = 'admin',
  agent = 'agent',
  vendor = 'vendor',
}
